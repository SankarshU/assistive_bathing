# ICRA 2027 Roadmap (submission Sept 2026) — written 2026-06-12

Companion to **`STATUS.md`** (the living current-state doc — read that first). This file is the long-term plan only.

> Phase-1 update (06-22): `squeeze` gap-closing run (entropy + curriculum + budget) FAILED to beat the 6.9 winner — see STATUS.md. Levers 1+2 rejected; open decision is now Lever 3 (handoff randomization) vs Lever 4 (re-ground threshold). Winner archived. 3-seed mechanism ready.

---

## ⭐ FINAL STRETCH — updated 2026-07-02 after full external review (supersedes Phases 2–4 below)

Where we actually are: Phases 2–3 largely DONE ahead of schedule — 4-region teachers (both
reward families), distillation working (`distill.py`, student ≥ specialists, beats flat
+26%), 9-method matrix @ n=2, paper draft exists (`ICRA_draft.tex/pdf`), behavior-metrics
battery live. Full review verdicts in `learn-bathing/REVIEW_AND_NEXT_STEPS.md` (sections
A/B). The stats bug in the headline p-value was found and FIXED 07-02 (correct stats:
12/12 region×seed pairs positive, exact Wilcoxon p=0.0005; per-seed t p=0.09, n=3).

**Remaining work, ranked by acceptance-probability impact:**

1. **Conditioned multi-task control (BIGGEST scientific gap — do first).** The headline
   says *distilled* student > flat baseline, but flat is *unconditioned*. Train ONE PPO
   policy multi-task over 4 regions WITH the region one-hot appended to obs (env change:
   ~10 lines to append context to `_get_obs`; new auto_loop config `flat_conditioned`).
   3 seeds, same eval. If student still wins → headline is bulletproof ("distillation, not
   conditioning"). If it ties → reframe headline around parity-at-lower-cost + quality
   metrics (still a paper; better to know now than from Reviewer 2). ~1 day CPU.
2. **9-method matrix → 3 seeds** (`SEEDS="1 2 3"`, resumable) → per-method quality gaps
   (in-band force, pass completions) become testable with the new stats machinery in
   `aggregate_4region.py`. ~3–4 h CPU.
3. **Canonical CSV regen** — one clean eval pass for every method (kills the
   Bflat/flat4 + Tours/spec4 duplicate-row contradictions); add active-overrides column.
4. **Held-out-region generalization** — distill from 3 regions, zero-shot the 4th
   (one distill+eval run). Strongest generalization claim available; elevates the paper.
5. **Interference learning-curve figure** — flat multi-task curve vs specialists from
   existing run.logs (no training). Visually justifies "why distillation".
6. **Poke-vs-pass video pair + film-strip figure** — render Yubik vs Ours on the same
   region/seed; the single most persuasive artifact for reviewers (Claim 1, still open).
7. **Paper mechanics:** recompile `ICRA_draft.pdf` from the CORRECTED .tex (shipped PDF
   still shows the wrong p=0.0019); sensitivity paragraph for clear_radius/force band;
   limitations paragraph already honest — keep it.
8. **Optional, only if all above land by ~Aug 20:** pose-bin teachers (3 coarse bins,
   hardest region) to make the "and poses" part of the thesis literal; otherwise soften
   thesis wording to regions (+style) and list poses as future work.

**Do-not-relitigate additions (post-review):** teacher reward = `abl4_endpass` 6-term
config (the earlier "frozen 8-term+fixes" decision was superseded by the ablation-ladder
finding that force/A/D/E rungs don't help — see README §3.2); identical episode protocol
for ALL methods incl. Yubik (drift-termination + wipe-start) is the declared design, now
documented in code/README — never call the Yubik rows a byte-identical reproduction.

**Handoff package for the collaborator:** `collab_handoff_20260702.zip` in the repo root
(self-contained: corrected code + paper + results + review + this roadmap). Reproduction
path: REVIEW_AND_NEXT_STEPS.md §C. First actions: item 1 above, then 2, 3.

## The paper we are writing (decide this first, work backward)

**Thesis:** A structured directional reward — self-supervised arm-axis from the remaining
target cloud, pass-aligned credit, windowed locality, evidence-gated completion — makes
*wiping* (not touching) emerge from RL in assistive bed bathing, and the resulting policies
distill into one context-conditioned policy across arm regions and poses.

**Claims and the evidence each requires:**

| # | Claim | Evidence | Status |
|---|---|---|---|
| 1 | Contact-counting rewards produce poking; ours produces passes | poke-vs-pass video pair + sweep/pass metrics on both | passes video done; need poke video + metrics |
| 2 | Each reward layer contributes | ablation table (no_fixes / no_DE / full / 8-term) | DONE (single seed) — needs 3 seeds |
| 3 | Extended shaping terms hurt (negative result) | 8 vs 13-term rows | DONE (single seed) |
| 4 | Reward transfers across regions/poses unchanged | multi-region + multi-pose training, same flags | not started |
| 5 | Teachers distill into one student with minor loss | distillation experiments, student-vs-teacher table | not started |
| 6 | Behavior is quantitatively "wiping" | pass-completion rate, sweep consistency, in-band force %, clear spatial order | metrics exist in info; need aggregation script |

**Reviewer attack surface (from the earlier critique) and our answers:**
- "Reward engineering, not science" → ablation table + emergent-behavior framing + negative result (claims 2,3,6)
- "Hand-tuned constants" → report sensitivity on the 2–3 constants that matter (clear_radius, force band); admit the rest
- "Not potential-based shaping" → cite Ng et al. 1999, evaluate only on task metrics (we already do)
- "Sim-only, capsule arm" → scope claims explicitly; cite RABBIT/Manip4Care for the sim-to-real path; do NOT promise hardware
- "Single seed" → 3 seeds minimum on headline numbers; report mean±std

## Timeline (≈14 weeks)

### Phase 1 — June 12 → June 30: lock single-region excellence
- Archive winner checkpoint (immediately).
- Close the 6.9 → 10.4 success gap, in this order (stop when success >50%):
  1. More budget on winner config (raise max-chunks to 12; PPO entropy_coeff 0.01 if plateaued)
  2. clear_radius curriculum 0.030→0.022 over first 1M steps
  3. Handoff-error randomization (seed gap 2–15 mm, 10% episodes 4 cm) + stall termination mirroring deployed Algorithm 2 — also strengthens the deployment-matching story
  4. If still short: question the threshold itself — 0.69 was inherited; justify a task-grounded one (e.g., %-area coverage) in the paper rather than chasing an arbitrary cliff
- Re-run the 4-config ablation with 3 seeds (auto_loop: add seed to configs; ~2 days CPU)
- Build `metrics_report.py`: aggregates per-episode info fields (pass completions, sweep consistency, in-band force fraction, drift rate, clear order) into the Claim-6 table
- **Exit criteria:** success rate >50% (or justified alternative metric), 3-seed ablation table, behavior-metrics table

### Phase 2 — July 1 → July 21: generalization
- Multi-region: 4 single-region configs + 1 all-region config (auto_loop + override hook). Decision point: if all-region within ~15% of single-region averages → regions don't need separate teachers, distillation contexts = poses only (simpler paper); else per-region teachers
- Multi-pose: 3–5 coarse pose bins (shoulder/elbow ranges) on the hardest region; per-bin teachers with frozen reward
- Optional (only if time): arm mass/compliance for within-episode pose drift (TODO 4) — strengthens realism, not required for thesis
- **Exit criteria:** region-transfer table, pose-bin teacher zoo with per-teacher metrics

### Phase 3 — July 22 → Aug 18: distillation (the headline)
- Week 1: `distill.py` — rollout collection from teachers (obs, context, action mean/std via weights-only loader), student π(a|o,c), BC + Gaussian-distill loss; validate student-vs-single-teacher on one context
- Weeks 2–3: full student across all contexts; compare: student vs each teacher vs one flat multi-task RL policy (the necessary baseline reviewers will ask for) vs zero-shot single-config policy
- Fallback if distillation underperforms: the multi-region/multi-pose results alone + reward story is still a paper; distillation becomes "future work" — decide by Aug 10
- **Exit criteria:** student within ~10% of teachers on each context, beats flat multi-task baseline

### Phase 4 — Aug 19 → Sept submission: write
- Paper skeleton (start Aug 19, not later):
  1. Intro: caregiving need, hybrid pipeline, "touching ≠ wiping"
  2. Related work: positioning doc already written (REWARD_UNIQUENESS_vs_BASELINE.md §4–5)
  3. Method: reward structure (ppt slide 6 pyramid), phase machine, axis/sweep/window/end, distillation
  4. Experiments: ablation, behavior metrics, generalization, distillation, negative result
  5. Limitations: sim-only, capsule arm, tuned constants, fixed threshold
- Figures: reward pyramid, pipeline, ablation bars, pass-trajectory plot (s vs t), poke-vs-pass film strip
- Internal review by professor ~Sept 1; one revision cycle; submit
- **Hard rule:** no new experiments after Sept 1 except reviewer-proofing reruns

## Standing decisions (do not relitigate without new evidence)
1. Reward frozen: 8 documented terms + fixes A–E + wipe-start init
2. Policy scope is wiping only; approach/retreat classical (deployment-matching argument, ppt slides 3–5)
3. Old leaky-env results are dead; never compared against
4. reward_mean never compared across configs; targets_cleared/task_success/behavior metrics only
5. Extended 5 terms: reported as negative ablation, not shipped

## Resource notes
- All training on user's mac CPU (~11 min/250k steps). Phase 1–2 fits comfortably; Phase 3 rollout collection is cheap (inference only). If a GPU/cluster becomes available, spend it on seeds, not bigger nets.
- Agent (Claude) cannot run sim; writes code/analysis, user executes. Update HANDOFF_CONTEXT after every milestone.
