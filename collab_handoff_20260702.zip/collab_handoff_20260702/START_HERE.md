# START HERE (read this first, in order)

Welcome! This bundle contains everything for the assistive bed-bathing wiping project
(ICRA submission, Sept 2026). This page tells you exactly what to do, in what order,
with copy-paste commands. Nothing here assumes prior knowledge of the project.

## What this project is (60 seconds)
A simulated UR5 robot arm wipes a human arm in PyBullet. We show that a carefully
*structured reward* makes reinforcement learning produce real back-and-forth wiping
passes (instead of random poking), and that four per-region policies can be *distilled*
into one region-conditioned policy that beats a jointly-trained baseline. The paper
draft is in `paper/ICRA_draft.pdf`.

## Reading order (one sitting, ~1 hour)
1. This file.
2. `README.md` — the method, reward equations, and how to run (skim §4–5 for now).
3. `paper/ICRA_draft.pdf` — the paper as it stands.
4. `REVIEW_AND_NEXT_STEPS.md` — an independent review of the whole project: what's
   verified, what was broken (one stats bug — already fixed), and your task list (§C–D).
5. `ROADMAP.md`, "FINAL STRETCH" section at top — your prioritized to-do list with the
   reasoning behind each item.

## Setting up (once, ~30 min)
```bash
git clone https://github.com/SankarshU/assistive_bathing.git
cd assistive_bathing
conda env create -f environment.yml     # python 3.8, ray 1.13, pybullet
conda activate learnbath
# now copy every file from this bundle's code/ folder into the repo root,
# overwriting what's there (the bundle versions are newer and bug-fixed):
cp -r /path/to/bundle/code/* .
# sanity check:
python -c "import socket;s=socket.socket();s.bind(('',0));print('network OK')"
python env_viewer.py                    # should open a PyBullet window with the robot
```

## Your first real task (reproduce before you create — this is non-negotiable)
```bash
caffeinate -dimsu bash run_icra_matrix.sh >> icra_matrix.log 2>&1 &
tail -f icra_matrix.log                 # watch; ~6-7 h on a laptop, resumable if killed
```
When done: `python make_icra_figure.py --seeds 1 2` and compare your numbers to
`results/` in this bundle. Expect: Student←Ours ≈ 6.3 targets cleared, Student←Yubik
≈ 6.7, scripted ≈ 4.5 (±seed noise). If they match, you have a working setup and you
understand the pipeline. Only then move on.

## Then, in this exact order (details + reasoning in ROADMAP.md "FINAL STRETCH")
1. **Conditioned multi-task control** — the one missing experiment that most affects
   acceptance. Train one PPO policy on all 4 regions WITH the region one-hot in the
   observation. 3 seeds. If the distilled student still wins, the headline claim is safe.
2. **Extend the matrix to 3 seeds** — edit `SEEDS="1 2 3"` in `run_icra_matrix.sh`, rerun
   (it skips finished work).
3. **Regenerate `behavior_metrics_summary.csv` in one clean pass** (there are duplicate
   rows with contradictory drift values — details in REVIEW_AND_NEXT_STEPS.md §A).
4. Held-out-region test, interference figure, poke-vs-pass video (ROADMAP items 4–6).

## Rules that will save you pain
- **Never compare `reward_mean` across methods.** Different methods use different reward
  functions. Compare only `targets_cleared` and the behavior metrics.
- **Every run must print a `[WipingEnv reset]` banner** showing which flags are active.
  If you don't see it, you're running the wrong code.
- `_env_overrides.json` in the repo root silently changes env behavior — check its
  contents whenever results look strange, and delete it between manual experiments.
- Training resumes/evals must point at a checkpoint FILE (path containing `checkpoint`),
  not a folder — otherwise RLlib crashes with a numpy TypeError (already worked around
  in `learn.py`, but good to know).
- The stats in the paper were corrected on 2026-07-02 (a p-value was computed with the
  wrong distribution). If you regenerate results, always report: the per-seed paired t
  AND the Wilcoxon over region×seed pairs. `aggregate_4region.py` now prints both.
- When in doubt: reproduce first, change one thing at a time, and write down which
  config/seed produced every number you keep.

## Who to ask
Pratyush (project lead) — design decisions, history, compute.
The review in REVIEW_AND_NEXT_STEPS.md documents *why* things are the way they are;
check it before re-deriving or "fixing" something that looks odd — it may be deliberate
(e.g., the Yubik baseline intentionally shares our episode protocol).
