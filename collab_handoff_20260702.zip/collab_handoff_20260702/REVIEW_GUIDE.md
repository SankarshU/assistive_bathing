# Review bundle — assistive bed-bathing (region-conditioned distillation)

Self-contained package for code + method + results review. ~1.2 MB (no training
checkpoints or logs — see the base repo to actually run training).

## Where to start (suggested reading order)
1. **`README.md`** — problem definition, model architecture, reward design (equations),
   distillation Algorithm 1, baselines, metric definitions, how to run, how to verify.
2. **`paper/ICRA_draft.pdf`** — the draft paper (read as PDF). LaTeX source `ICRA_draft.tex`,
   markdown `ICRA_draft.md`.
3. **`results/`** — `ICRA_matrix_figure.png` (9-method comparison, curated metrics),
   `ICRA_matrix_figure_full.png` (all 19 metrics), `*_table.txt` (numbers),
   `behavior_metrics_summary.csv` (every eval row, 100-ep mean±std).
4. **`code/`** — the scripts (all latest, bug-fixed).

## Code map
- `learn_bathing/envs/wiping_env.py` — the MDP + both reward families (Ours structured /
  Yubik contact-counting). Reward assembly is in the `compute_reward` region.
- `learn.py` — PPO train/eval (RLlib). `auto_loop.py` — chunked trainer + all method configs.
- `distill.py` — collect / train / eval / render (the distillation, Algorithm 1).
- `metrics_report.py` — behavior-metric reducers; `scripted_baseline.py` — non-RL baseline;
  `trace_aggregate.py` — trajectory spread metrics.
- `run_icra_matrix.sh` — full 9-method, 2-seed matrix (resumable, network-safe).
  `run_4region_3seed.sh` — 3-seed headline with paired t-test. `make_icra_figure.py` — figure.

## Key claims to check
- Student←Ours vs Flat baseline: **+26% targets cleared; 12/12 region×seed pairs positive, exact Wilcoxon p=0.0005 (per-seed t p=0.09, n=3)** —
  `ICRA_4region_table.txt`.
- Distilled student matches/beats its per-region specialists (parity, n=2).
- Reward design (not RL/distillation scheme) decides safety: Ours best on in-band force
  (0.177) and pass completions (0.725) — `results/ICRA_matrix_table.txt`.

## Honest caveats (already in the paper, Sec. Limitations)
- The 9-method matrix is n=2 seeds → per-method gaps are suggestive, not significance-tested;
  only Ours-vs-Flat is (n=3).
- To run training, clone the base repo `https://github.com/SankarshU/assistive_bathing.git`,
  `conda env create -f code/environment.yml`, drop in these files, then follow README §4.
