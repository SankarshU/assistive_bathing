# Task for Fable

Hi Fable,

The review package is up to date at `/Users/pratyush/Desktop/Research/ROBO/Wiping/learn-bathing`
— start with `REVIEW_GUIDE.md`, and `fable_review.zip` is the self-contained bundle (code,
method, paper, results; no checkpoints — it's meant to be reproduced from scratch).

Please do a thorough pass on:

- **Code** — correctness and clarity of the env/reward (`learn_bathing/envs/wiping_env.py`),
  the distillation (`distill.py`), the training orchestration (`auto_loop.py`,
  `run_icra_matrix.sh`), and the metrics/eval (`metrics_report.py`, `make_icra_figure.py`).
- **Method** — the structured reward (equations in README §3 / paper Sec. 2.4), the
  region-conditioned distillation (Algorithm 1), and the style/general variants.
- **Experiments & results** — the 9-method matrix and the n=3 headline (Student←Ours vs flat:
  +26%, paired p=0.0019). Sanity-check the claims against
  `results/behavior_metrics_summary.csv` and flag anything not statistically supported.

Then please **update `REVIEW_AND_NEXT_STEPS.md`** so a human collaborator can (1) cleanly
reproduce the current results end-to-end first, and (2) then run the follow-ups (extending the
matrix to 3 seeds, the interference learning-curve figure, held-out-region generalization).

Also — remember `project.ppt`: it defines a class of methods with **two non-RL algorithms
beyond this RL-based approach**. Please account for those in your review and give concrete
**direction on how to integrate them** with this pipeline (where they slot in relative to the
specialists/distillation, what interfaces they'd share, and how we'd benchmark them
head-to-head under the same metrics).

Thanks!
