# Assistive Bed-Bathing via Region-Conditioned Policy Distillation

Reproducible code and experiments for learning a **single robot wiping policy** that
generalizes across four regions of a supine human arm (forearm back/front, upper-arm
back/front), distilled from per-region RL specialists, and benchmarked against a naive
contact-counting reward, a flat multi-task policy, and a non-RL scripted controller.

Simulator: PyBullet (UR5 arm + tool wiping a supine humanoid). RL: RLlib PPO (Ray 1.13).

---

## 1. Problem definition

**Task.** A UR5 manipulator holds a soft wiping tool and must clean the skin over a
target region of a supine human arm. The region is discretized into up to 15 cleanable
**targets**; a target is *cleared* when the tool passes within `clear_radius` (0.022 m)
of it while in contact. An episode is 150 steps.

**Observation** (`OBS_DIM = 90`): robot joint state, end-effector pose, tool–skin contact
geometry, and the target/region encoding produced by the environment.

**Action** (`ACT_DIM = 6`): continuous end-effector displacement command (mapped to joint
motion via IK inside the environment).

**Objective.** Not merely to maximize targets cleared, but to wipe *the way a caregiver
should*: complete, systematic coverage of the region while keeping contact force inside a
safe therapeutic band (2–12 N). Raw clear-count and clinical quality can diverge — a key
finding of this work — so we evaluate on a battery of behavior metrics (Section 5), not a
single scalar.

**Generalization question (the paper's core).** Region-specialist policies are easy to
train but impractical to deploy (one network per body part). Can a *single*
context-conditioned policy, distilled from the specialists, match or beat them across all
regions — and does the *reward design*, rather than the RL algorithm, determine whether the
resulting behavior is clinically safe?

---

## 2. Method / model architecture

### 2.1 Teacher policies (RL specialists)
One PPO policy per (region, reward) pair, trained with RLlib 1.13.

- Policy/value network: `fcnet_hiddens = [100, 100]`, tanh.
- PPO: `train_batch_size = 19200`, `num_sgd_iter = 50`, `sgd_minibatch_size = 128`.
- Training is chunked (~250k steps/chunk) with early-stopping and best-checkpoint
  archiving (`auto_loop.py`, `archive_best`).

### 2.2 Student policy (region-conditioned, distilled)
A single feed-forward Gaussian policy that conditions on the region:

```
input   = [ obs(90) , context ]
context = region one-hot(4)  [ + optional style bit(1) ]
backbone = MLP(128, 128) with tanh            # distill._build_student
heads    = mean_head    -> mean(6)
           log_std_head -> log_std(6), clamped to [-5, 2]   # diagonal Gaussian
```

The context one-hot selects which region the single network should act for; at deployment
you set the bit for the current body part. The optional **style bit** (Section 2.4) lets one
network reproduce *either* reward family's behavior on demand.

### 2.3 Distillation objective
Teachers are rolled out in their region; we record `(obs, teacher_mean(6),
teacher_log_std(6), context)`. The student is fit to the pooled data with a
behavior-cloning + distributional term:

```
loss = BC + beta * KL
BC   = MSE( student_mean , teacher_mean )
KL   = KL( teacher_diagGaussian || student_diagGaussian )     # distill._kl_diag_gauss (mode-covering)
optimizer = Adam(lr = 1e-3)
```

This matches both the teacher's action *mean* and its *uncertainty*, not just the mean.

**Algorithm 1 — Region-conditioned distillation**
```
Input: teachers {π_r} for r in R; context map c(r); rollout length N; weight β;
       optional style values {σ_r}
1. Collect:  for each region r, roll out π_r for N steps; record
             (o, μ_r(o), logσ_r(o), c(r))   # teacher DiagGaussian params
             (append style bit to c(r) if given)
2. Pool:     D = ∪_r D_r
3. Train:    π_θ(a | o, c)  by minibatch Adam(1e-3):
             L = MSE(μ_θ, μ_T) + β·KL( N_θ || N_T )
Output: one conditioned student π_θ
```

### 2.4 Distillation variants compared
- **Student ← Ours** — distilled from the 4 structured-reward specialists (our method).
- **Student ← Yubik** — distilled from the 4 contact-counting specialists.
- **Student ← Both (style-conditioned)** — one network distilled from all 8 specialists
  with a style bit (ours=0 / yubik=1); reproduces either behavior via the bit.
- **Student ← Both (general)** — one network distilled from all 8 with **no** style bit;
  irreversibly blends the two behaviors.

### 2.5 Baselines (non-distillation)
- **Ours / Yubik specialists** — the per-region PPO teachers themselves (four networks; upper
  bound for their reward but not a single deployable policy).
- **Flat baseline** (`region_all_4`) — a *single* PPO policy trained jointly on all four
  regions with the Ours reward and **no** region conditioning. This is the direct multi-task
  alternative to distillation, and the bar the student must beat.
- **Non-RL scripted** (`scripted_baseline.py`) — a geometric boustrophedon sweep executed by
  inverse kinematics; no learning. Lower bound on task competence.

---

## 3. Reward design

Both reward families share the same base; ours adds structural shaping terms. All reward
terms are gated, and the baseline branch pays exactly the original 3-term total. Note the
precise scope: episode *mechanics* (drift termination and wipe-start initialization) apply
to BOTH families — that is deliberate, so the only difference between methods is the reward
itself, under one identical episode protocol. The Yubik rows are therefore "the
contact-counting reward under our episode protocol", not a re-run of the original repo.

### 3.1 Baseline reward (`use_baseline_reward = True`, "Yubik")
The original contact-counting RL reward (from `yubink2/learn-bathing`, git `96fb9af`):

```
r = 1.0 * (-d_arm)  +  0.01 * (-||a||^2)  +  5.0 * contacts
```

distance-to-target, an action-magnitude penalty, and a large bonus per contact. It clears
targets aggressively but has no notion of *where along the arm* it is or whether it is
covering the region systematically.

### 3.2 Structured reward ("Ours", config `abl4_endpass`)
Adds four shaping terms on top of the base (later ablation rungs — force shaping, no-contact
penalty, gap penalty, wipe-exit penalty, drift-termination — are **off** for the teacher
reward; see `_ABL_LADDER` in `auto_loop.py`):

```
r_ours = w_d·r_dist + w_a·r_act + w_c·r_clr + w_s·r_sweep + w_w·r_win + w_e·r_end
weights (w_d, w_a, w_c, w_s, w_w, w_e) = (1.0, 0.01, 5.0, 1.0, 1.0, 1.0)
r_act = -||a||^2 ;  r_clr = c_t  (targets cleared this step)
```

1. **Two-phase / sticky distance** (`r_dist`) — `-d_arm` while reaching, along-surface
   distance once wiping, so the policy is rewarded for staying on-surface.
2. **Directional sweep** (`r_sweep`) — rewards monotone progress along a **self-supervised
   arm axis**. The principal axis `u` is estimated by SVD of the target cloud (refreshed
   ~200 steps); the tool projects onto it to give `s = clip((⟨p−p̄, u⟩ − s_min)/span, 0, 1)`.
   With `Δs_dir = ρ·(s_t − s_{t−1})` for pass direction `ρ∈{±1}`:
   `r_sweep = k_f·min(Δs_dir, δ)` if `Δs_dir>ε`; `= −k_b·min(−Δs_dir, δ)` if `Δs_dir<−ε`;
   else `0`  (`k_f=0.5, k_b=0.75, ε=0.01, δ=0.05`; active only in contact).
3. **Local window** (`r_win = 0.5·n_win_contact + 0.25·n_win_clears`) — credits contact/clears
   near the current `s`, discouraging teleport-style jumps between distant targets.
4. **Evidence-gated end-of-pass bonus** (`r_end = B`, `B=4.0`) — granted when a pass reaches
   an end (`s≥0.90` forward / `s≤0.10` backward) **and** the pass accumulated ≥1 in-window
   hit/clear; else `0`. The gate prevents farming the bonus by sweeping empty space.

Contact phase is stabilized with a **soft-contact latch + hysteresis**
(`contact_latch_steps = 6`) so brief force dropouts don't flip the wipe/exit state.

The net effect: the structured reward produces **complete, systematic, force-safe** wiping,
trading a small amount of raw clear-count for markedly better coverage and force safety
(Section 5, results).

---

## 4. Setup & how to run

### 4.1 Environment
```bash
git clone https://github.com/SankarshU/assistive_bathing.git
cd assistive_bathing            # scripts live at the repo root
conda env create -f environment.yml      # python 3.8, ray 1.13, pybullet 3.2.7, gym 0.15.3
conda activate learnbath
```

Sanity-check that Ray can start (the exact failure mode we hardened against):
```bash
python -c "import socket; s=socket.socket(); s.bind(('',0)); print('OK'); s.close()"
```

### 4.2 Single-policy quick start (original entry points)
```bash
python env_viewer.py            # visualize the environment
python learn.py --train         # train one PPO policy
python learn.py --render        # render a trained policy
python learn.py --evaluate      # evaluate a trained policy
```

### 4.3 Reproduce the full 9-method matrix (2 seeds, 4 regions)
One resumable, network-safe orchestrator does everything — trains the teachers, distills the
four students, evaluates every method + baselines, and renders the figure:

```bash
caffeinate -dimsu bash run_icra_matrix.sh >> icra_matrix.log 2>&1 &
```

It is **fully resumable** (skips finished teachers/students/eval rows), **self-caffeinates**
(keeps macOS awake so the network stack can't sleep-wedge Ray), and **aborts loudly instead
of silently skipping a seed** if the network wedges — re-running continues exactly where it
stopped. Runtime ~6–7 h on a laptop (dominated by RL training). To add a third seed, edit
`SEEDS="1 2 3"` and re-launch.

### 4.4 Headline significance run (Ours student vs flat baseline, 3 seeds)
```bash
caffeinate -dimsu bash run_4region_3seed.sh >> 4region_3seed.log 2>&1 &
```
Produces `ICRA_4region_table.txt` with a paired t-test across seeds.

### 4.5 Regenerate figures/tables from existing results (no training)
```bash
python make_icra_figure.py --seeds 1 2                 # curated headline (9 metrics)
python make_icra_figure.py --seeds 1 2 --full --out ICRA_matrix_figure_full.png   # all 19
```

---

## 5. Metrics

All methods are scored by the **same reducers** (`metrics_report.episode_metrics`), 100
episodes/region, force band 2–12 N, `clear_radius = 0.022` — so every row is comparable.
Results append to `behavior_metrics_summary.csv`.

**Headline (curated, discriminative) set** used in the main figure:

| Metric | Meaning | Better |
|---|---|---|
| Targets cleared /15 | region targets cleaned | higher |
| p95 contact force (N) | 95th-pct force (gentleness) | lower |
| In-band force fraction | fraction of contact within 2–12 N | higher |
| Pass completions | full sweeps completed | higher |
| Sweep consistency | regularity of the sweep motion | higher |
| Clear s-coverage | fraction of arm-length bins with a clear | higher |
| Clear t-coverage | fraction of time bins with a clear | higher |
| 2nd-half fraction | clears in the 2nd half (sustained, not front-loaded) | higher |
| Drift-termination rate | episodes ending in runaway drift | lower |

The remaining 10 metrics (task success, region covered, time wiping, mean/peak force,
action effort/smoothness, clear spatial order, productive/stall fraction) are near-identical
across methods or redundant; they are dropped from the headline and kept only under `--full`
for the appendix.

---

## 6. Repository / file manifest (all latest, bug-fixed)

**Environment**
- `learn_bathing/envs/wiping_env.py` — the wiping MDP, both reward families. *Includes the
  upperarm_back env-hang fix (axis-trial-order guard) enabling all 4 regions.*

**Training / distillation / eval**
- `learn.py` — PPO train/eval entry (RLlib). *Ray init pinned to `127.0.0.1` (socket fix).*
- `auto_loop.py` — chunked trainer; all method configs (`abl4_endpass`=ours, `baseline_rl`/
  `yubik_*`=yubik, `region_all_4`=flat), `--seed`, best-checkpoint archiving.
- `distill.py` — `collect / train / eval / render`. *`ALL4_REGIONS` collect fix; Ray fix;
  style-bit support.*
- `metrics_report.py` — behavior-metric reducers + shared summary CSV writer. *Ray fix.*
- `scripted_baseline.py` — non-RL geometric wiping baseline. *Now appends to the shared
  summary CSV (fix); Ray fix.*
- `trace_aggregate.py` — trajectory overlays + spread/efficiency metrics. *Ray fix.*

**Orchestration / analysis**
- `run_icra_matrix.sh` — the full 9-method, 2-seed matrix (network-gated, self-caffeinating,
  resumable).
- `run_4region_3seed.sh` — the 3-seed Ours-student-vs-flat headline with paired t-test.
- `aggregate_4region.py` — cross-seed aggregation + paired test for the 4-region study.
- `make_icra_figure.py` — the comparison figure + text table (`--full` for all 19 metrics).

**Outputs**
- `behavior_metrics_summary.csv` — every eval row (label, 100-ep mean±std per metric).
- `ICRA_matrix_figure.png` / `ICRA_matrix_table.txt` — the 9-method comparison.
- `ICRA_4region_table.txt` — the n=3 significance table.

---

## 7. How to verify a reproduction

1. `python -c "import ast,glob; [ast.parse(open(f).read()) for f in glob.glob('*.py')]"` —
   all modules parse.
2. Run `run_icra_matrix.sh`; confirm `behavior_metrics_summary.csv` gains `Aours_/Ayubik_/
   AstyO_/AstyY_/Agen_/Tours_/Tyubik_/Bflat_/Bscr_` rows (9 methods × 4 regions × seeds).
3. `python make_icra_figure.py --seeds 1 2` — the printed "STORY" block should show
   Student←Ours ≈ 6.3, Student←Yubik ≈ 6.7, non-RL ≈ 4.5 (numbers within seed noise).
4. Cross-check `ICRA_4region_table.txt`: Ours student > flat baseline, paired p < 0.05.

---

## 8. Known limitations (honest)

- The 9-method matrix is **n = 2 seeds**; per-method differences (e.g. the ~0.4-clear
  Ours-vs-Yubik gap, and the force-safety advantages) are **suggestive, not
  significance-tested**. The only significance-tested claim is Ours-student vs flat baseline
  (+26 %; positive in 12/12 region×seed pairs, exact Wilcoxon p = 0.0005; per-seed paired t
  p = 0.09 at n = 3 seeds). Extend `SEEDS` to 3 to test the quality metrics.
- `task_success` (clearing all 15 targets) is ~0 for all methods — the task is hard; we grade
  on targets-cleared, not success.
- Some metrics favor the non-RL baseline in isolation (region-covered, clear-spatial-order)
  purely because it sweeps wide arcs while clearing very little — raw coverage ≠ effective,
  safe cleaning. Interpret metrics jointly.
