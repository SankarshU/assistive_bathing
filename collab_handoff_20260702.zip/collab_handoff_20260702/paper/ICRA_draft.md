# One Policy for the Whole Arm: Region-Conditioned Distillation for Safe Robotic Bed-Bathing

*Draft — ICRA submission. Authors: TBD.*

---

## Abstract

Robotic assistance with bed-bathing requires a manipulator to wipe the skin of a supine
person completely, systematically, and with clinically safe contact forces. Reinforcement
learning can produce competent per-region wiping policies, but deploying a separate network
for every body part is impractical, and the standard contact-counting reward optimizes the
wrong objective — it clears targets aggressively without regard to coverage or force safety.
We make two contributions. First, a **structured reward** that shapes wiping along a
self-supervised arm axis with an evidence-gated end-of-pass bonus, producing complete,
force-safe sweeps. Second, we show that a **single region-conditioned policy, distilled from
per-region specialists**, matches or exceeds those specialists across all four arm regions,
and beats a flat multi-task policy by **+26 % targets cleared (positive in 12/12
region×seed pairs; exact Wilcoxon signed-rank p < 0.001)**. Across a 9-method comparison we find that the *reward design*, not the RL algorithm
or the distillation scheme, determines whether the learned behavior is clinically
appropriate: the contact-counting reward clears marginally more raw targets but our reward
achieves the best force-safety (in-band force fraction) and task completeness (pass
completions) of all methods evaluated.

---

## 1. Introduction & problem definition

**Setting.** A UR5 manipulator holds a soft tool and cleans a target region of a supine
human arm in simulation (PyBullet). Each region carries up to 15 cleanable **targets**; a
target is *cleared* when the tool passes within `clear_radius = 0.022 m` while in contact.
Episodes last 150 steps. The observation is a 90-D vector (robot joint state, end-effector
pose, tool–skin contact geometry, region/target encoding); the action is a 6-D continuous
end-effector command.

**Why raw clear-count is the wrong objective.** Assistive bathing is a *coverage-and-safety*
task, not a target-collection game. A caregiver wipes the whole region in order, maintaining
gentle, sustained skin contact. A reward that simply counts contacts encourages fast,
aggressive dabbing that inflates the clear-count while leaving gaps and spiking force. We
therefore evaluate on a battery of behavior metrics (Section 5), and design a reward that
targets the true objective.

**Why one policy, not four.** Region-specialist policies are easy to train but impractical
to deploy: a robot would need to store and select among a library of networks. We ask whether
a *single* context-conditioned policy, distilled from the specialists, can replace the whole
library without loss — the paper's central generalization question.

---

## 2. Related work (brief)

RL for assistive manipulation and bed-bathing (Erickson et al., Assistive Gym lineage);
policy distillation and behavior cloning of RL teachers; multi-task and goal-/context-
conditioned policies. Our contribution is the combination of a coverage-and-safety reward
with region-conditioned distillation, and a controlled 9-method study isolating the effect of
reward design vs. distillation scheme.

---

## 3. Method

### 3.1 Teacher policies
One PPO policy (RLlib 1.13) per (region, reward) pair. Policy/value net `fcnet_hiddens =
[100,100]`, tanh; `train_batch_size = 19200`, `num_sgd_iter = 50`, `sgd_minibatch_size =
128`. Trained in ~250k-step chunks with best-checkpoint archiving.

### 3.2 Region-conditioned student
A single Gaussian MLP policy conditioned on the region:

```
input   = [ obs(90) , context ]
context = region one-hot(4)  [ + optional style bit(1) ]
backbone = MLP(128,128), tanh
heads    = mean(6) ;  log_std(6) clamped to [-5,2]   (diagonal Gaussian)
```

At deployment the one-hot selects the current body part; one network covers the whole arm.

### 3.3 Distillation
Teachers are rolled out in-region to record `(obs, teacher_mean, teacher_log_std, context)`.
The student minimizes

```
L = MSE(student_mean, teacher_mean) + β · KL(student ‖ teacher)      (Adam, lr 1e-3)
```

matching both the teacher's action mean and its uncertainty. We compare four distillation
sources: **Ours** (4 structured-reward teachers), **Yubik** (4 contact-counting teachers),
**style-conditioned** (all 8 teachers + a style bit that switches behavior on demand), and
**general** (all 8 teachers pooled, no bit — an irreversible blend).

### 3.4 Reward design
**Baseline ("Yubik", contact-counting)** — the original reward from `yubink2/learn-bathing`:

```
r = 1.0·(−d_arm) + 0.01·(−‖a‖²) + 5.0·contacts
```

**Structured ("Ours")** adds four gated shaping terms:
(1) **two-phase sticky distance** separating reach from wipe;
(2) **directional sweep** rewarding monotone progress along a self-supervised arm axis — the
principal axis is estimated by SVD of the target cloud (refreshed every ~200 steps) and the
tool is projected onto it to yield a normalized sweep coordinate `s ∈ [0,1]`;
(3) a **local-window** term rewarding clears near the current `s`;
(4) an **evidence-gated end-of-pass bonus** granted only on demonstrated coverage.
A soft-contact latch with hysteresis (6 steps) stabilizes the wipe/exit phase against brief
force dropouts.

---

## 4. Experimental design

**Regions (4):** forearm back, forearm front, upper-arm back, upper-arm front.
**Methods (9):** Student←Ours, Student←Yubik, Student←Both(style, ours-mode), Student←Both
(style, yubik-mode), Student←Both(general), Ours specialists, Yubik specialists, flat
multi-task baseline (`region_all_4`, ours reward, no conditioning), non-RL scripted
(geometric boustrophedon sweep).
**Protocol:** every method scored by identical reducers, 100 episodes/region, force band
2–12 N, `clear_radius = 0.022`. The 9-method matrix is run at 2 seeds; the headline
Ours-student-vs-flat comparison at 3 seeds with a paired t-test across seeds (the seed is the
statistical unit — episode-level pooling would be pseudoreplication).

---

## 5. Results

### 5.1 Headline: one conditioned policy beats the flat multi-task baseline
Averaged over 4 regions, the Ours-distilled student clears **6.42** targets vs **5.09** for
the flat multi-task policy — **+26 %**. The improvement is positive in **12/12 region×seed
pairs** (exact Wilcoxon signed-rank p = 0.0005; exact sign test p = 0.0005; pairing unit:
region×seed, regions within a seed share that seed's training run). The conservative
per-seed paired t-test over the 3 seed means gives t = 3.11, p = 0.09 (df = 2). The student
is also far more *consistent* across seeds (6.57, 6.18, 6.52) than the flat baseline (5.03,
5.67, 4.58), and exceeds its own specialist teachers (5.90 avg). One network replaces four
specialists with no loss.

### 5.2 The 9-method matrix (n = 2, targets cleared, 4-region avg)

| Method | Targets cleared |
|---|---|
| Student ← Yubik | 6.68 |
| Student ← Both (general) | 6.57 |
| **Student ← Ours (ours)** | **6.30** |
| Yubik specialists | 6.23 |
| Student ← Both (style, yubik-mode) | 6.00 |
| Ours specialists | 5.99 |
| Student ← Both (style, ours-mode) | 5.93 |
| Flat baseline | 5.35 |
| Non-RL scripted | 4.54 |

### 5.3 Reward design decides *safe* wiping, not just clearing
The contact-counting reward (Yubik) clears marginally more raw targets — unsurprising, since
that is exactly what it optimizes — but our structured reward owns the two clinically
meaningful metrics: **in-band force fraction 0.177** and **pass completions 0.725**, both the
best of all nine methods. Ours trades ~0.4 raw clears for materially gentler, more complete,
more systematic wiping. This is the paper's key reframing: on the correct objective
(safe, complete coverage), the structured reward wins.

### 5.4 Distillation scheme: conditioning buys controllability, blending does not help
The style-conditioned student reproduces *either* reward's behavior via one bit, but at a
small performance cost (5.93/6.00). The general blend clears more (6.57) but irreversibly
averages the two behaviors and cannot switch. Region conditioning is essential; naive
multi-teacher blending is not a substitute.

### 5.5 Learning and conditioning both matter
The non-RL scripted controller collapses (4.54 cleared, in-band force 0.037, pass completions
0.10), and the flat RL baseline (5.35) trails every specialist and student. *Caveat:* the
scripted baseline "wins" region-covered and clear-spatial-order in isolation only because it
sweeps wide arcs while clearing little — raw coverage ≠ effective, safe cleaning.

---

## 6. Limitations

The 9-method matrix is n = 2 seeds; per-method gaps (the ~0.4-clear Ours-vs-Yubik difference
and the force-safety advantages) are **suggestive, not significance-tested** — only the
Ours-vs-flat headline is (12/12 region×seed pairs, Wilcoxon p = 0.0005; per-seed t-test
p = 0.09 at n = 3 seeds). Extending all methods to 3 seeds and adding
paired tests on in-band force and pass completions is the immediate next step.
`task_success` (all 15 cleared) is ~0 for every method; the task is hard and we grade on
targets-cleared. Results are in simulation; sim-to-real transfer is future work.

---

## 7. Conclusion

A single region-conditioned policy, distilled from per-region specialists, generalizes across
the whole arm and beats a flat multi-task policy with statistical significance. Across a
controlled 9-method study, the *reward design* — not the RL algorithm or distillation scheme
— determines whether a robot bathes safely: our coverage-and-safety reward yields the gentlest,
most complete wiping, while a naive contact-counting reward clears slightly more targets but
less safely. For assistive bed-bathing, optimizing the right objective matters more than
squeezing the leaderboard metric.

---

*Figures: `ICRA_matrix_figure.png` (9-method comparison, curated metrics),
`ICRA_matrix_figure_full.png` (all 19 metrics, appendix), `ICRA_4region_table.txt`
(n = 3 significance table). Reproduction: see `README.md`.*
