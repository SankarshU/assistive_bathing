#!/usr/bin/env bash
# run_icra_matrix.sh — the FULL ICRA comparison matrix, 2 seeds, all 4 regions.
#
# Methods produced (each a single 4-region policy unless noted):
#   student  <- OURS teachers            (region-conditioned)
#   student  <- YUBIK teachers           (region-conditioned)
#   student  <- OURS+YUBIK, STYLE-cond   (region + style bit; ours=0 / yubik=1, switchable)
#   student  <- OURS+YUBIK, GENERAL      (pooled, no style bit; one blended net)
#   teachers : OURS specialists (per region)   + YUBIK specialists (per region)
#   baselines: FLAT (region_all_4, ours reward) + NON-RL scripted
# All scored on the SAME metric set (metrics_report reducers: 100 eps, force band 2-12 N,
# clear_radius 0.022) so every row in behavior_metrics_summary.csv is comparable.
#
# ROBUSTNESS (lessons from the lost day):
#   * Self-caffeinate: keeps the Mac awake for the script's lifetime so the network stack
#     can't sleep-wedge (that was the root cause of the Ray "Can't assign requested address").
#   * Network gates: before every Ray phase we verify a socket can bind; on failure we
#     retry with backoff, then ABORT (exit) with fix instructions -- we NEVER silently skip
#     a seed and produce a degraded table. Re-running resumes exactly where it stopped.
#   * Fully resumable: reuses done teachers, students, collected data, and eval rows.
# bash 3.2 safe (no associative arrays). Tee'd to icra_matrix.log.
# Recommended launch (after run_4region_3seed.sh finishes):
#   caffeinate -dimsu bash run_icra_matrix.sh >> icra_matrix.log 2>&1 &
set -u
cd "$(dirname "$0")"
LOG="icra_matrix.log"; mkdir -p d4x

# ---- self-guard: prevent system/display/disk/idle sleep for our lifetime ----
if command -v caffeinate >/dev/null 2>&1; then
  caffeinate -dims -w "$$" >/dev/null 2>&1 &
  echo "[guard] caffeinate holding the Mac awake for pid $$" | tee -a "$LOG"
fi

SEEDS="1 2"
REGIONS="forearm_back forearm_front upperarm_back upperarm_front"
CTX="forearm_back,forearm_front,upperarm_back,upperarm_front"
MR="--episodes 100 --clear-radius 0.022 --force-lo 2 --force-hi 12"

say(){ echo -e "\n===== [$(date '+%F %T')] $* =====" | tee -a "$LOG"; }
phase(){ echo -e "\n########## PHASE: $* ##########" | tee -a "$LOG"; }
bestck(){ find "trained_models/auto/$1_s$2/BEST" -name 'checkpoint-*' ! -name '*.tune_metadata' 2>/dev/null | head -1; }
have_row(){ grep -q "^$1," behavior_metrics_summary.csv 2>/dev/null; }
ours_cfg(){ case "$1" in
  forearm_back) echo abl4_endpass ;; forearm_front) echo ours_front ;;
  upperarm_back) echo ours_upperarm_back ;; upperarm_front) echo ours_upperarm_front ;;
esac; }
yubik_cfg(){ case "$1" in
  forearm_back) echo baseline_rl ;; forearm_front) echo yubik_front ;;
  upperarm_back) echo yubik_upperarm_back ;; upperarm_front) echo yubik_upperarm_front ;;
esac; }

# ---- network gate: the exact failure that cost us a day. Bind INADDR_ANY like Ray does. ----
require_net(){
  local i
  for i in 1 2 3 4 5 6 7 8; do
    if python -c "import socket; s=socket.socket(); s.bind(('',0)); s.close()" >/dev/null 2>&1; then
      return 0
    fi
    echo "[net] socket bind('',0) failing (Ray-style errno 49). try $i/8, wait 20s..." | tee -a "$LOG"
    sleep 20
  done
  echo "" | tee -a "$LOG"
  echo "[net] ABORT: network stack wedged -- INADDR_ANY bind still failing after retries." | tee -a "$LOG"
  echo "[net] This is the post-sleep macOS socket wedge, NOT a code bug." | tee -a "$LOG"
  echo "[net] Fix: reboot (or 'sudo ifconfig lo0 up'); keep lid OPEN + power plugged;" | tee -a "$LOG"
  echo "[net] then just re-run this script -- it resumes exactly here. Nothing is lost." | tee -a "$LOG"
  exit 3
}

# ---- ensure teachers for a seed; heal+resume on transient net failure; abort (never skip) ----
teachers_ready(){ # $1=seed  -> prints missing list, empty if all present
  local S="$1" miss="" r
  [ -z "$(bestck region_all_4 "$S")" ] && miss="$miss region_all_4"
  for r in $REGIONS; do
    [ -z "$(bestck "$(ours_cfg  "$r")" "$S")" ] && miss="$miss ours:$r"
    [ -z "$(bestck "$(yubik_cfg "$r")" "$S")" ] && miss="$miss yubik:$r"
  done
  echo "$miss"
}

phase "PREFLIGHT"
require_net
echo "[preflight] network OK; caffeinate active; starting matrix." | tee -a "$LOG"

# =========================== NON-RL scripted baseline ===========================
# seed-independent (non-learning): one run per region.
phase "NON-RL scripted baseline (4 regions)"
require_net
for r in $REGIONS; do
  if have_row "Bscr_${r}"; then echo "[skip] Bscr_${r} exists" | tee -a "$LOG"; else
    python scripted_baseline.py --region "$r" --seed 1 --metrics --label "Bscr_${r}" \
      --episodes 100 --clear-radius 0.022 --force-lo 2 --force-hi 12 2>&1 | tee -a "$LOG"
  fi
done

for S in $SEEDS; do
  # ------------------------------- PHASE 1: teachers -------------------------------
  phase "SEED $S / 1-TEACHERS (train ours + yubik + flat; skips DONE)"
  require_net
  python auto_loop.py --configs \
    abl4_endpass ours_front ours_upperarm_back ours_upperarm_front \
    baseline_rl yubik_front yubik_upperarm_back yubik_upperarm_front \
    region_all_4 --seed "$S" 2>&1 | tee -a "$LOG"

  miss="$(teachers_ready "$S")"
  if [ -n "$miss" ]; then
    echo "[seed $S] teachers missing after pass 1 ->$miss ; net-heal + resume once" | tee -a "$LOG"
    require_net
    python auto_loop.py --configs \
      abl4_endpass ours_front ours_upperarm_back ours_upperarm_front \
      baseline_rl yubik_front yubik_upperarm_back yubik_upperarm_front \
      region_all_4 --seed "$S" 2>&1 | tee -a "$LOG"
    miss="$(teachers_ready "$S")"
  fi
  if [ -n "$miss" ]; then
    echo "[seed $S] ABORT: teachers still missing ->$miss" | tee -a "$LOG"
    echo "[seed $S] Not skipping/aggregating a partial result. Fix cause, re-run to resume." | tee -a "$LOG"
    exit 4
  fi
  FLAT=$(bestck region_all_4 "$S")

  # ------------------------------- PHASE 2: collect --------------------------------
  phase "SEED $S / 2-COLLECT distill data (ours / yubik / style0 / style1)"
  require_net
  for r in $REGIONS; do
    OCK=$(bestck "$(ours_cfg "$r")" "$S"); YCK=$(bestck "$(yubik_cfg "$r")" "$S")
    [ -s "d4x/o_s${S}_${r}.npz" ]  || python distill.py collect --region "$r" --checkpoint "$OCK" --contexts "$CTX"            --out "d4x/o_s${S}_${r}.npz"  2>&1 | tee -a "$LOG"
    [ -s "d4x/y_s${S}_${r}.npz" ]  || python distill.py collect --region "$r" --checkpoint "$YCK" --contexts "$CTX"            --out "d4x/y_s${S}_${r}.npz"  2>&1 | tee -a "$LOG"
    [ -s "d4x/so_s${S}_${r}.npz" ] || python distill.py collect --region "$r" --checkpoint "$OCK" --contexts "$CTX" --style 0 --out "d4x/so_s${S}_${r}.npz" 2>&1 | tee -a "$LOG"
    [ -s "d4x/sy_s${S}_${r}.npz" ] || python distill.py collect --region "$r" --checkpoint "$YCK" --contexts "$CTX" --style 1 --out "d4x/sy_s${S}_${r}.npz" 2>&1 | tee -a "$LOG"
  done

  # ------------------------------- PHASE 3: distill --------------------------------
  phase "SEED $S / 3-DISTILL 4 students"
  require_net
  [ -s "student_ours4_s${S}.pt" ]  || python distill.py train --data "d4x/o_s${S}_*.npz"     --out "student_ours4_s${S}.pt"  2>&1 | tee -a "$LOG"
  [ -s "student_yubik4_s${S}.pt" ] || python distill.py train --data "d4x/y_s${S}_*.npz"     --out "student_yubik4_s${S}.pt" 2>&1 | tee -a "$LOG"
  [ -s "student_gen4_s${S}.pt" ]   || python distill.py train --data "d4x/[oy]_s${S}_*.npz"  --out "student_gen4_s${S}.pt"   2>&1 | tee -a "$LOG"
  [ -s "student_style4_s${S}.pt" ] || python distill.py train --data "d4x/s[oy]_s${S}_*.npz" --out "student_style4_s${S}.pt" 2>&1 | tee -a "$LOG"

  # ------------------------------- PHASE 4: eval -----------------------------------
  phase "SEED $S / 4-EVAL students + teachers + flat (full metrics)"
  require_net
  eval_student(){ # $1=ptfile $2=tag  [$3=style value]
    local tag="$2" need=0 r
    for r in $REGIONS; do have_row "${tag}_${r}" || need=1; done
    if [ "$need" -eq 0 ]; then echo "[skip] $tag rows exist" | tee -a "$LOG"; return; fi
    if [ "${3:-__none__}" = "__none__" ]; then
      python distill.py eval --student "$1" --tag "$tag" --regions $REGIONS 2>&1 | tee -a "$LOG"
    else
      python distill.py eval --student "$1" --tag "$tag" --regions $REGIONS --style "$3" 2>&1 | tee -a "$LOG"
    fi
  }
  eval_student "student_ours4_s${S}.pt"  "Aours_s${S}"
  eval_student "student_yubik4_s${S}.pt" "Ayubik_s${S}"
  eval_student "student_gen4_s${S}.pt"   "Agen_s${S}"
  eval_student "student_style4_s${S}.pt" "AstyO_s${S}" 0
  eval_student "student_style4_s${S}.pt" "AstyY_s${S}" 1

  for r in $REGIONS; do
    OCK=$(bestck "$(ours_cfg "$r")" "$S"); YCK=$(bestck "$(yubik_cfg "$r")" "$S")
    have_row "Tours_s${S}_${r}"  || python metrics_report.py --checkpoint "$OCK"  --label "Tours_s${S}_${r}"  --region "$r" $MR 2>&1 | tee -a "$LOG"
    have_row "Tyubik_s${S}_${r}" || python metrics_report.py --checkpoint "$YCK"  --label "Tyubik_s${S}_${r}" --region "$r" $MR 2>&1 | tee -a "$LOG"
    have_row "Bflat_s${S}_${r}"  || python metrics_report.py --checkpoint "$FLAT" --label "Bflat_s${S}_${r}"  --region "$r" $MR 2>&1 | tee -a "$LOG"
  done
done

phase "AGGREGATE -> ICRA comparison figure + table"
python make_icra_figure.py --seeds $SEEDS 2>&1 | tee -a "$LOG"
say "DONE. figure: ICRA_matrix_figure.png ; table: ICRA_matrix_table.txt"
