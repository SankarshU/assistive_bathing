#!/usr/bin/env bash
# run_4region_3seed.sh — the headline 4-region generalization across 3 seeds, FULL metrics.
# Per seed: train 4 ours specialists + flat baseline, distill ONE 4-region student, eval
# student/specialists/flat per region. Then aggregate across seeds (aggregate_4region.py).
# Resumable (auto_loop skips DONE). bash 3.2 safe. Tee'd to 4region_3seed.log.
set -u
cd "$(dirname "$0")"
LOG="4region_3seed.log"; mkdir -p d4
say(){ echo -e "\n===== [$(date '+%F %T')] $* =====" | tee -a "$LOG"; }
bestck(){ find "trained_models/auto/$1_s$2/BEST" -name 'checkpoint-*' ! -name '*.tune_metadata' 2>/dev/null | head -1; }
cfg_for(){ case "$1" in
  forearm_back)   echo abl4_endpass ;; forearm_front)  echo ours_front ;;
  upperarm_back)  echo ours_upperarm_back ;; upperarm_front) echo ours_upperarm_front ;;
esac; }
REGIONS="forearm_back forearm_front upperarm_back upperarm_front"
CTX="forearm_back,forearm_front,upperarm_back,upperarm_front"
SEEDS="1 2 3"

for S in $SEEDS; do
  say "SEED $S : train 4 specialists + flat (skips DONE)"
  python auto_loop.py --configs abl4_endpass ours_front ours_upperarm_back ours_upperarm_front region_all_4 --seed "$S" 2>&1 | tee -a "$LOG"
  FLAT=$(bestck region_all_4 "$S")
  [ -z "$FLAT" ] && { echo "[seed $S] flat missing -> skip seed" | tee -a "$LOG"; continue; }
  ok=1; for r in $REGIONS; do [ -z "$(bestck "$(cfg_for "$r")" "$S")" ] && ok=0; done
  [ "$ok" -eq 0 ] && { echo "[seed $S] a teacher missing -> skip seed" | tee -a "$LOG"; continue; }

  say "SEED $S : collect + distill 4-region student"
  for r in $REGIONS; do
    ck=$(bestck "$(cfg_for "$r")" "$S")
    python distill.py collect --region "$r" --checkpoint "$ck" --contexts "$CTX" --out "d4/s${S}_$r.npz" 2>&1 | tee -a "$LOG"
  done
  python distill.py train --data "d4/s${S}_*.npz" --out "student_ours_4region_s$S.pt" 2>&1 | tee -a "$LOG"

  say "SEED $S : eval student / specialists / flat (full metrics)"
  python distill.py eval --student "student_ours_4region_s$S.pt" --tag "dstl4_s$S" --regions $REGIONS 2>&1 | tee -a "$LOG"
  for r in $REGIONS; do
    ck=$(bestck "$(cfg_for "$r")" "$S")
    python metrics_report.py --checkpoint "$ck"   --label "spec4_s${S}_${r}" --region "$r" --episodes 100 --clear-radius 0.022 --force-lo 2 --force-hi 12 2>&1 | tee -a "$LOG"
    python metrics_report.py --checkpoint "$FLAT" --label "flat4_s${S}_${r}" --region "$r" --episodes 100 --clear-radius 0.022 --force-lo 2 --force-hi 12 2>&1 | tee -a "$LOG"
  done
done

say "AGGREGATE across seeds -> ICRA table"
python aggregate_4region.py --seeds 1 2 3 2>&1 | tee -a "$LOG"
python results_tracker.py >/dev/null 2>&1
say "DONE. ICRA table in ICRA_4region_table.txt ; rows dstl4_s*/spec4_s*/flat4_s* in CSV"
