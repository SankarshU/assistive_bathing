#!/usr/bin/env python3
"""
trace_aggregate.py — multi-episode trajectory comparison + candidate wiping metrics.

For each policy, runs N episodes, OVERLAYS all their s-vs-time traces (so the figure
reflects the distribution of behavior, not one lucky episode), and computes several
candidate "wiping quality" metrics per episode -> reports mean +/- std across episodes.
We then keep only metrics that ROBUSTLY separate methods (others are artifacts).

Metrics (per episode):
  cleared              targets cleared
  clear_time_span      (last_clear_step - first_clear_step)/episode_len   [distributed clearing in TIME]
  clear_s_span         max-min of s where clears happen                   [distributed clearing in SPACE]
  second_half_frac     fraction of targets cleared in the 2nd half        [keeps clearing vs stops early]
  productive_frac      contact steps within +/-W steps of a clear / contact steps   [non-wasted contact]
  stall_frac           in-contact steps with |ds|<eps (not moving along arm)        [parking]

    python trace_aggregate.py --region forearm_back --episodes 30 \
      --policy student student_ours.pt  "Ours" \
      --policy student student_yubik.pt "Yubik" \
      --out aggregate_ours_vs_yubik.png
"""
import argparse, os
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))


def ep_metrics(S, K, A, W=4, eps=0.01):
    S=np.asarray(S,float); K=np.asarray(K,float); A=np.asarray(A,int); n=len(S)
    out={}
    ci=np.where(K>0)[0]; ctot=float(K.sum())
    out["cleared"]=ctot
    # COVERAGE (spread vs clustered): how many of B bins along the arm / in time
    # actually contain a clear. High = spread across the arm; low = clustered.
    # (Range/span was wrong: two outlier clusters inflate it.)
    B=10
    cs=S[(K>0)&(S>=0)]
    if len(cs):
        sb=np.clip((cs*B).astype(int),0,B-1)
        out["clear_s_coverage"]=len(set(sb.tolist()))/B
    else: out["clear_s_coverage"]=np.nan
    if len(ci):
        tb=np.clip((ci/n*B).astype(int),0,B-1)
        out["clear_t_coverage"]=len(set(tb.tolist()))/B
    else: out["clear_t_coverage"]=np.nan
    out["second_half_frac"]=(K[n//2:].sum()/ctot) if ctot>0 else np.nan
    # productive contact: contact steps within W of any clear step
    prod=0; cset=set(ci)
    contact=np.where(A==1)[0]
    for t in contact:
        if any((t-w) in cset or (t+w) in cset for w in range(W+1)): prod+=1
    out["productive_frac"]=(prod/len(contact)) if len(contact) else np.nan
    # stall: contact steps where s barely moves
    ds=np.abs(np.diff(S, prepend=S[0]))
    mask=(A==1)&(S>=0)
    out["stall_frac"]=float(np.mean(ds[mask]<eps)) if mask.sum() else np.nan
    return out


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--policy",nargs=3,action="append",metavar=("KIND","PATH","LABEL"),required=True)
    ap.add_argument("--region",default="forearm_back")
    ap.add_argument("--episodes",type=int,default=30)
    ap.add_argument("--seed",type=int,default=1)
    ap.add_argument("--out",default="aggregate.png")
    args=ap.parse_args()

    import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
    import multiprocessing, ray, torch
    import distill as D
    from learn import make_env, load_policy
    D._set_env_overrides(args.region)
    ray.init(num_cpus=multiprocessing.cpu_count(),ignore_reinit_error=True,log_to_driver=False, _node_ip_address="127.0.0.1")

    panels=[]
    for kind,path,label in args.policy:
        env=make_env(D.ENV_NAME,seed=args.seed)
        if kind=="rl":
            agent,_=load_policy(env,"ppo",D.ENV_NAME,path,seed=args.seed,extra_configs={"num_workers":0,"num_gpus":0},render=True)
            act=lambda o: agent.compute_action(o,explore=False)
        else:
            ck=torch.load(path,map_location="cpu"); st=D._build_student(ck["n_ctx"],tuple(ck["hidden"]))
            st.load_state_dict(ck["state_dict"]); st.eval(); cv=D.context_vec(args.region,ck["regions"])
            def act(o,st=st,cv=cv):
                with torch.no_grad():
                    m,_=st(torch.tensor(np.concatenate([np.asarray(o,np.float32),cv])[None],dtype=torch.float32))
                return m.numpy()[0]
        traces=[]; mets=[]
        for ep in range(args.episodes):
            o=env.reset(); done=False; S=[];K=[];Acc=[]
            while not done:
                o,_,done,info=env.step(act(o)); S.append(info.get("s",-1.0))
                K.append(info.get("clears_this_step",0)); Acc.append(info.get("accepted_contact_exists",0))
            traces.append((np.array(S),np.array(K))); mets.append(ep_metrics(S,K,Acc))
        env.close(); panels.append((label,traces,mets))

    # figure: overlay all episode traces per policy
    fig,axes=plt.subplots(len(panels),1,figsize=(10,3.2*len(panels)),sharex=True)
    if len(panels)==1: axes=[axes]
    for ax,(label,traces,mets) in zip(axes,panels):
        for S,K in traces:
            sv=np.where(S>=0,S,np.nan); ax.plot(sv,color="#1D9E75",alpha=0.18,lw=1)
            kc=K>0; t=np.arange(len(S)); ax.scatter(t[kc],sv[kc],s=10,color="#D85A30",alpha=0.5)
        cl=np.nanmean([m["cleared"] for m in mets])
        ax.set_ylim(-0.05,1.05); ax.set_ylabel("position along arm  s")
        ax.set_title(f"{label}  -  {len(traces)} episodes overlaid  (mean cleared {cl:.1f})",fontsize=11)
        ax.grid(alpha=0.2)
    axes[-1].set_xlabel("timestep")
    fig.tight_layout(); fig.savefig(os.path.join(HERE,args.out),dpi=130)
    print(f"[trace_aggregate] saved {args.out}\n")

    # metrics table: mean +/- std across episodes (printed AND saved to a .txt I can read)
    keys=["cleared","clear_s_coverage","clear_t_coverage","second_half_frac","productive_frac","stall_frac"]
    lines=[f"# trace_aggregate | region={args.region} | episodes={args.episodes}",
           f"{'metric':18}"+"".join(f"{p[0]:>18}" for p in panels)]
    for k in keys:
        row=f"{k:18}"
        for label,traces,mets in panels:
            v=np.array([m[k] for m in mets],float); v=v[~np.isnan(v)]
            row+=f"{np.mean(v):8.3f}+-{np.std(v):<7.3f}" if len(v) else f"{'-':>18}"
        lines.append(row)
    txt="\n".join(lines); print("\n"+txt)
    mpath=os.path.join(HERE, os.path.splitext(args.out)[0]+"_metrics.txt")
    with open(mpath,"w") as f: f.write(txt+"\n")
    print(f"\n[trace_aggregate] metrics saved -> {os.path.basename(mpath)}")


if __name__=="__main__":
    main()
