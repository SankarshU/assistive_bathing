import os
import numpy as np
import random
import pybullet as p
from gym import spaces

from .env import AssistiveEnv


class WipingEnv(AssistiveEnv):
    def __init__(self):
        super(WipingEnv, self).__init__()
        self.right_shoulder = 6
        self.right_elbow = 7
        self.right_wrist = 8
        self.human_controllable_joints = [3, 4, 5, 7]
        self.human_right_arm = [3, 4, 5, 6, 7, 8]

        # wiping task parameters (from assistive gym config)
        self.robot_forces = 1.0
        self.robot_gains = 0.05
        self.distance_weight = 1.0
        self.action_weight = 0.01
        self.wiping_reward_weight = 5.0
        self.task_success_threshold = 0.6

                # ---- reward shaping upgrades (paper-inspired) ----
        self.reach_switch_dist = 0.10     # meters; switch reach->wipe shaping
        self.near_target_dist = 0.06      # meters; dense proximity shaping
        self.contact_band_min = 2.0       # N  (start easier than 5N)
        self.contact_band_max = 12.0      # N
        self.force_weight = 0.002          # tune 0.01-0.05
        self.near_target_weight = 0.5     # tune 0.2-1.0
        self.clear_radius = 0.035         # curriculum: start >0.025, tighten later

        # continuity (optional later)
        self.prev_contact_pos = None
        self.jump_thresh = 0.10
        self.jump_gamma = 0.3

    def step(self, action):
        # 1) Apply action (advance physics + controller)
        self.take_step(action, gains=self.robot_gains, forces=self.robot_forces)
    
        # 2) Compute wiping signals from contacts (updated function)
        clears, contact_pos, normal_force, near_target_contact = self.get_new_contact_points()
    
        # 3) Observation after the step
        obs = self._get_obs()
    
        # 4) Distance-to-arm (phase-1) using closest points
        if 'upperarm' in self.arm_side:
            closest_points = self.bc.getClosestPoints(
                bodyA=self.tool, bodyB=self.humanoid._humanoid, distance=100.0,
                linkIndexA=1, linkIndexB=self.right_shoulder, physicsClientId=self.bc._client
            )
        elif 'forearm' in self.arm_side:
            closest_points = self.bc.getClosestPoints(
                bodyA=self.tool, bodyB=self.humanoid._humanoid, distance=100.0,
                linkIndexA=1, linkIndexB=self.right_elbow, physicsClientId=self.bc._client
            )
        else:
            closest_points = []
    
        if closest_points:
            d_arm = min([c[8] for c in closest_points])
            reward_reach = -d_arm
        else:
            d_arm = 1.0
            reward_reach = -1.0
    
        # 5) Distance-to-targets (phase-2): once close to arm, shape toward remaining markers
        if len(self.feasible_targets_pos_world) > 0:
            tool_pos = np.array(self.bc.getLinkState(
                self.tool, 1, computeForwardKinematics=True, physicsClientId=self.bc._client
            )[0])
            d_targets_mean = float(np.mean([np.linalg.norm(tool_pos - np.array(tw)) for tw in self.feasible_targets_pos_world]))
            reward_wipe_dist = -d_targets_mean
        else:
            reward_wipe_dist = 0.0
    
        # Two-phase switch (reach -> wipe)
        reward_distance = reward_reach if d_arm > self.reach_switch_dist else reward_wipe_dist
    
        # 6) Action penalty
        reward_action = -np.sum(np.square(action))
    
        # 7) Wipe progress reward (sparse clears)
        reward_clears = float(clears)
    
        # 8) Dense proxy reward: any contact near remaining targets
        reward_near_target = float(near_target_contact)
    
        # 9) Force-band shaping (encourage safe sustained contact)
        # inside [min,max] => 0 penalty; outside => negative penalty; no contact => small penalty
        if normal_force <= 1e-6:
            reward_force = -1.0
        else:
            if normal_force < self.contact_band_min:
                reward_force = -(self.contact_band_min - normal_force)
            elif normal_force > self.contact_band_max:
                reward_force = -(normal_force - self.contact_band_max)
            else:
                reward_force = 0.0
    
        # 10) Total reward
        reward = (
            self.distance_weight * reward_distance +
            self.action_weight * reward_action +
            self.wiping_reward_weight * reward_clears +
            self.near_target_weight * reward_near_target +
            self.force_weight * reward_force
        )
    
        # 11) Info + termination
        info = {
            'number_of_targets_cleared': self.task_success,
            'total_target_count': self.total_target_count,
            'feasible_target_count': self.feasible_targets_count,
            'task_success': int(self.task_success >= (self.feasible_targets_count * self.task_success_threshold)),
            'task_percentage': self.task_success / self.feasible_targets_count * 100,
            'action_robot_len': self.action_robot_len,
            'obs_robot_len': self.obs_robot_len,
    
            # Optional debug signals (helpful right now)
            "d_arm": float(d_arm),
            "normal_force": float(normal_force),
            "near_target_contact": int(near_target_contact),
            "clears_this_step": int(clears),
            "n_remaining_targets": int(len(self.feasible_targets_pos_world)),
        }
        done = bool(self.task_success >= (self.feasible_targets_count * self.task_success_threshold))
        if getattr(self, "_dbg_t", 0) % 20 == 0:
            print(f"d_arm={d_arm:.3f}  force={normal_force:.2f}  near={near_target_contact}  clears={clears}  n_targets={len(self.feasible_targets_pos_world)}")
            self._dbg_t = getattr(self, "_dbg_t", 0) + 1
            
        return obs, reward, done, info
    

    def get_new_contact_points(self):
        """
        Returns:
          clears: int (#targets cleared this step)
          contact_pos: np.array or None (one representative contact position on human)
          normal_force: float (sum of normal forces for tool-human contacts this step)
          near_target_contact: int (1 if contact is within near_target_dist of any remaining target)
        """
        clears = 0
        contact_pos = None
        normal_force = 0.0
        near_target_contact = 0

        # Cache for speed
        targets_world = self.feasible_targets_pos_world

        for c in self.bc.getContactPoints(bodyA=self.tool, bodyB=self.humanoid._humanoid, physicsClientId=self.bc._client):
            linkA = c[3]
            linkB = c[4]
            posB = np.array(c[6])          # contact position on human
            fn = float(c[9]) if len(c) > 9 else 0.0  # normal force (Bullet contact tuple)

            if linkA != 1:
                continue
            if linkB < 0 or linkB not in self.human_right_arm:
                continue

            # Accumulate force + store a representative contact point
            normal_force += fn
            contact_pos = posB

            # Dense proxy: if we are contacting near ANY remaining target -> give signal
            if len(targets_world) > 0:
                # nearest target distance
                dmin = np.min([np.linalg.norm(posB - np.array(tw)) for tw in targets_world])
                if dmin < self.near_target_dist:
                    near_target_contact = 1

            # Sparse: clear targets if within radius
            indices_to_delete = []
            for i, (target_pos_world, target) in enumerate(zip(self.feasible_targets_pos_world, self.feasible_targets)):
                if np.linalg.norm(posB - np.array(target_pos_world)) < self.clear_radius:
                    clears += 1
                    self.task_success += 1
                    self.bc.resetBasePositionAndOrientation(target, [1000, 1000, 1000], [0, 0, 0, 1], physicsClientId=self.bc._client)
                    indices_to_delete.append(i)

            if indices_to_delete:
                self.feasible_targets_pos = [t for i, t in enumerate(self.feasible_targets_pos) if i not in indices_to_delete]
                self.feasible_targets = [t for i, t in enumerate(self.feasible_targets) if i not in indices_to_delete]
                self.feasible_targets_pos_world = [t for i, t in enumerate(self.feasible_targets_pos_world) if i not in indices_to_delete]

        return clears, contact_pos, normal_force, near_target_contact

    def _get_obs(self):
        obs = np.ones(self.obs_robot_len)*30  # padding irrelevant obs values to 30
        real_obs_len = 3 + 4 + 6 + len(self.feasible_targets_pos_world)*3

        tool_pos, tool_orn = self.bc.getLinkState(self.tool, 1, computeForwardKinematics=True, physicsClientId=self.bc._client)[:2]
        tool_pos = np.array(tool_pos)
        tool_orn = np.array(tool_orn)

        robot_joint_states = self.bc.getJointStates(self.robot.id, jointIndices=self.robot.arm_controllable_joints, physicsClientId=self.bc._client)
        robot_joint_positions = np.array([x[0] for x in robot_joint_states])

        real_obs = np.concatenate([tool_pos, tool_orn, robot_joint_positions] + list(self.feasible_targets_pos_world)).ravel().astype(np.float32)
        obs[:real_obs_len] = real_obs

        return obs
    def resetx(self):
        self.bc.resetSimulation(self.bc._client)
        self.setup_timing()
        self.create_world()
    
        self.task_success = 0
        self.prev_contact_pos = None  # Mine
        self.contact_points_on_arm = {}
        self.robot_lower_limits = self.robot.arm_lower_limits
        self.robot_upper_limits = self.robot.arm_upper_limits
    
        feasible_targets_found = False
        while True:
            # randomize human arm config and check for collisions
            self.robot.reset()
            self.reset_and_check()
    
            feasible_targets_found = self.generate_targets()
    
            if not feasible_targets_found:
                self.remove_targets()
                continue
    
            # mark feasible targets
            if self.gui:
                self.mark_feasible_targets()
    
            # initialize tool & compute eef_to_tool
            self.robot.reset()
            self.init_tool()
    
            # reset robot to init config (NOW should be the *closer* IK pose)
            for i, joint_id in enumerate(self.robot.arm_controllable_joints):
                self.bc.resetJointState(
                    self.robot.id,
                    joint_id,
                    self.init_q_R[i],
                    physicsClientId=self.bc._client
                )
    
            # reset tool and attach it to eef
            world_to_eef = self.bc.getLinkState(
                self.robot.id,
                self.robot.eef_id,
                computeForwardKinematics=True,
                physicsClientId=self.bc._client
            )[:2]
            world_to_tool = self.bc.multiplyTransforms(
                world_to_eef[0], world_to_eef[1],
                self.eef_to_tool[0], self.eef_to_tool[1],
                physicsClientId=self.bc._client
            )
            self.bc.resetBasePositionAndOrientation(
                self.tool,
                world_to_tool[0],
                world_to_tool[1],
                physicsClientId=self.bc._client
            )
            self.attach_tool()
            for _ in range(20):
                self.bc.stepSimulation(physicsClientId=self.bc._client)
            
                eef_pos = self.bc.getLinkState(self.robot.id, self.robot.eef_id, computeForwardKinematics=True,
                                               physicsClientId=self.bc._client)[0]
                tool_pos, _ = self.bc.getBasePositionAndOrientation(self.tool, physicsClientId=self.bc._client)
                
                d_eef = float(np.min(np.linalg.norm(np.array(self.feasible_targets_pos_world) - np.array(eef_pos), axis=1)))
                d_tool = float(np.min(np.linalg.norm(np.array(self.feasible_targets_pos_world) - np.array(tool_pos), axis=1)))
                
                print("[RESET DEBUG] d_min(eef->target) =", d_eef, " d_min(tool->target) =", d_tool)
                print("[RESET DEBUG] eef_pos =", eef_pos, " tool_pos =", tool_pos)
                print("[RESET DEBUG] |tool-eef| =", float(np.linalg.norm(np.array(tool_pos) - np.array(eef_pos))))
        
            # IMPORTANT: let constraints/contacts settle
            # for _ in range(20):
            #     self.bc.stepSimulation(physicsClientId=self.bc._client)
    
            # print(f'init_q_R (closer): {self.init_q_R}')
            # # Optional sanity print
            # eef_pos = self.bc.getLinkState(self.robot.id, self.robot.eef_id, computeForwardKinematics=True, physicsClientId=self.bc._client)[0]
            # print("EEF pos:", eef_pos, "Target mean:", self.world_to_target_point[0],
            #       "dist:", np.linalg.norm(np.array(eef_pos) - np.array(self.world_to_target_point[0])))
    
            if feasible_targets_found:
                break
    
        return self._get_obs()

    def reset(self):
        self.bc.resetSimulation(self.bc._client)
        self.setup_timing()
        self.create_world()
    
        self.task_success = 0
        self.prev_contact_pos = None
        self.contact_points_on_arm = {}
        self.robot_lower_limits = self.robot.arm_lower_limits
        self.robot_upper_limits = self.robot.arm_upper_limits
    
        feasible_targets_found = False
        while True:
            # randomize human arm config and check for collisions
            self.robot.reset()
            self.reset_and_check()
    
            # IMPORTANT: init tool BEFORE generate_targets()
            # because get_feasible_targets_pos() relies on eef_to_tool / tool convention.
            self.robot.reset()
            self.init_tool()
    
            feasible_targets_found = self.generate_targets()
    
            if not feasible_targets_found:
                # cleanup before retry (prevents tool pile-up / slowdowns)
                self.remove_targets()
                if hasattr(self, "cid") and self.cid is not None:
                    try:
                        self.bc.removeConstraint(self.cid, physicsClientId=self.bc._client)
                    except Exception:
                        pass
                    self.cid = None
                if hasattr(self, "tool") and self.tool is not None:
                    try:
                        self.bc.removeBody(self.tool, physicsClientId=self.bc._client)
                    except Exception:
                        pass
                    self.tool = None
                continue
    
            # mark feasible targets
            if self.gui:
                self.mark_feasible_targets()
    
            # reset robot to init config (tool-aware "closer" IK pose)
            for i, joint_id in enumerate(self.robot.arm_controllable_joints):
                self.bc.resetJointState(
                    self.robot.id,
                    joint_id,
                    self.init_q_R[i],
                    physicsClientId=self.bc._client
                )
    
            # reset tool and attach it to eef (tool pose from current eef pose)
            world_to_eef = self.bc.getLinkState(
                self.robot.id,
                self.robot.eef_id,
                computeForwardKinematics=True,
                physicsClientId=self.bc._client
            )[:2]
    
            world_to_tool = self.bc.multiplyTransforms(
                world_to_eef[0], world_to_eef[1],
                self.eef_to_tool[0], self.eef_to_tool[1],
                physicsClientId=self.bc._client
            )
    
            self.bc.resetBasePositionAndOrientation(
                self.tool,
                world_to_tool[0],
                world_to_tool[1],
                physicsClientId=self.bc._client
            )
    
            self.attach_tool()
    
            # settle constraints/contacts (keep small for speed)
            for _ in range(5):
                self.bc.stepSimulation(physicsClientId=self.bc._client)
    
            # DEBUG (guarded)
            if getattr(self, "debug", False):
                eef_pos = self.bc.getLinkState(
                    self.robot.id, self.robot.eef_id,
                    computeForwardKinematics=True,
                    physicsClientId=self.bc._client
                )[0]
                tool_pos, _ = self.bc.getBasePositionAndOrientation(self.tool, physicsClientId=self.bc._client)
    
                d_eef = float(np.min(np.linalg.norm(np.array(self.feasible_targets_pos_world) - np.array(eef_pos), axis=1)))
                d_tool = float(np.min(np.linalg.norm(np.array(self.feasible_targets_pos_world) - np.array(tool_pos), axis=1)))
    
                print("[RESET DEBUG] d_min(eef->target) =", d_eef, " d_min(tool->target) =", d_tool)
                print("[RESET DEBUG] eef_pos =", eef_pos, " tool_pos =", tool_pos)
                print("[RESET DEBUG] |tool-eef| =", float(np.linalg.norm(np.array(tool_pos) - np.array(eef_pos))))
    
            break
    
        return self._get_obs()
    def generate_targets(self):
        self.target_indices_to_ignore = []
        self.upperarm_length, self.upperarm_radius = 0.144000+0.036000, 0.036000
        self.forearm_length, self.forearm_radius = 0.108000+0.028000*2, 0.028000

        # generate capsule points
        self.targets_pos_on_upperarm = self.util.capsule_points(p1=np.array([0, 0, 0]), p2=np.array([0, 0, -self.upperarm_length]), 
                                                                radius=self.upperarm_radius, distance_between_points=0.03)
        self.targets_pos_on_forearm = self.util.capsule_points(p1=np.array([0, 0, -0.01]), p2=np.array([0, 0, -self.forearm_length-0.01]), 
                                                                radius=self.forearm_radius, distance_between_points=0.03)
        
        # create target points
        sphere_collision = -1
        sphere_visual = p.createVisualShape(shapeType=p.GEOM_SPHERE, radius=0.01, rgbaColor=[0, 1, 1, 1], physicsClientId=self.bc._client)
        self.targets_upperarm = []
        self.targets_forearm = []
        for _ in range(len(self.targets_pos_on_upperarm)):
            self.targets_upperarm.append(self.bc.createMultiBody(baseMass=0.0, baseCollisionShapeIndex=sphere_collision, baseVisualShapeIndex=sphere_visual, 
                                                           basePosition=[0, 0, 0], useMaximalCoordinates=False, physicsClientId=self.bc._client))
        for _ in range(len(self.targets_pos_on_forearm)):
            self.targets_forearm.append(self.bc.createMultiBody(baseMass=0.0, baseCollisionShapeIndex=sphere_collision, baseVisualShapeIndex=sphere_visual, 
                                                          basePosition=[0, 0, 0], useMaximalCoordinates=False, physicsClientId=self.bc._client))
        self.total_target_count = len(self.targets_upperarm) + len(self.targets_forearm)

        # move targets to initial positions
        self.update_targets()

        # feasible targets
        feasible_targets_found = self.get_feasible_targets_pos()

        return feasible_targets_found
    
    def remove_targets(self):
        for target in self.targets_upperarm:
            self.bc.removeBody(target, physicsClientId=self.bc._client)
        for target in self.targets_forearm:
            self.bc.removeBody(target, physicsClientId=self.bc._client)

    def update_targets(self):
        upperarm_pos, upperarm_orient = self.bc.getLinkState(self.humanoid._humanoid, self.right_shoulder, computeForwardKinematics=True, physicsClientId=self.bc._client)[4:6]
        upperarm_orient = self.util.rotate_quaternion_by_axis(upperarm_orient, axis='x', degrees=-90)
        self.targets_pos_upperarm_world = []
        for target_pos_on_arm, target in zip(self.targets_pos_on_upperarm, self.targets_upperarm):
            target_pos, target_orn = self.bc.multiplyTransforms(upperarm_pos, upperarm_orient, target_pos_on_arm, [0, 0, 0, 1], physicsClientId=self.bc._client)
            self.targets_pos_upperarm_world.append(target_pos)
            self.bc.resetBasePositionAndOrientation(target, target_pos, target_orn, physicsClientId=self.bc._client)

        forearm_pos, forearm_orient = self.bc.getLinkState(self.humanoid._humanoid, self.right_elbow, computeForwardKinematics=True, physicsClientId=self.bc._client)[4:6]
        forearm_orient = self.util.rotate_quaternion_by_axis(forearm_orient, axis='x', degrees=-90)
        self.targets_pos_forearm_world = []
        for target_pos_on_arm, target in zip(self.targets_pos_on_forearm, self.targets_forearm):
            target_pos, target_orn = self.bc.multiplyTransforms(forearm_pos, forearm_orient, target_pos_on_arm, [0, 0, 0, 1], physicsClientId=self.bc._client)
            self.targets_pos_forearm_world.append(target_pos)
            self.bc.resetBasePositionAndOrientation(target, target_pos, target_orn, physicsClientId=self.bc._client)

    def mark_feasible_targets(self):
        # change color for feasible targets
        for target in self.feasible_targets:
            self.bc.changeVisualShape(target, -1, rgbaColor=[0, 0.2, 1, 1], physicsClientId=self.bc._client)
    def get_feasible_targets_pos(self):
    
        self.target_order_flags = {
            'upperarm_front': False,
            'upperarm_back': False,
            'forearm_front': False,
            'forearm_back': False
        }
    
        # Simplified mode
        self.target_trial_order = ['upperarm_front']
        self.target_axis_trial_order = [0]
    
        feasible_targets_found = False
    
        def split_targets(targets_pos, axis):
            coords = np.array([pos[axis] for pos in targets_pos])
            mid = np.median(coords)
            front_idx = [i for i, pos in enumerate(targets_pos) if pos[axis] > mid]
            back_idx  = [i for i, pos in enumerate(targets_pos) if pos[axis] <= mid]
            return front_idx, back_idx
    
        # -----------------------------
        # NEW: IK reach check helper
        # -----------------------------
        def ik_reaches_pose(q, desired_pos, max_err=0.03):
            """
            Apply q (via resetJointState), step once, and check if achieved EEF is close
            to desired_pos. This prevents accepting bad IK solutions (the main bug).
            """
            for i, joint_id in enumerate(self.robot.arm_controllable_joints):
                self.bc.resetJointState(self.robot.id, joint_id, q[i], physicsClientId=self.bc._client)
    
            self.bc.stepSimulation(physicsClientId=self.bc._client)
    
            eef_pos = self.bc.getLinkState(
                self.robot.id, self.robot.eef_id,
                computeForwardKinematics=True,
                physicsClientId=self.bc._client
            )[0]
    
            err = float(np.linalg.norm(np.array(desired_pos) - np.array(eef_pos)))
            return err <= max_err, err
    
        for axis in self.target_axis_trial_order:
    
            front_u, back_u = split_targets(self.targets_pos_on_upperarm, axis)
            front_f, back_f = split_targets(self.targets_pos_on_forearm, axis)
    
            self.target_pos_world_dict = {
                'upperarm_front': np.array(self.targets_pos_upperarm_world)[front_u],
                'upperarm_back':  np.array(self.targets_pos_upperarm_world)[back_u],
                'forearm_front':  np.array(self.targets_pos_forearm_world)[front_f],
                'forearm_back':   np.array(self.targets_pos_forearm_world)[back_f]
            }
    
            self.target_dict = {
                'upperarm_front': np.array(self.targets_upperarm)[front_u],
                'upperarm_back':  np.array(self.targets_upperarm)[back_u],
                'forearm_front':  np.array(self.targets_forearm)[front_f],
                'forearm_back':   np.array(self.targets_forearm)[back_f]
            }
    
            for order_key in self.target_trial_order:
    
                # Reset robot cleanly
                self.robot.reset()
    
                targets_pos_world = self.target_pos_world_dict[order_key]
                targets = self.target_dict[order_key]
    
                if len(targets_pos_world) == 0:
                    continue
    
                # Compute mean target position
                mean_target = tuple(np.mean(targets_pos_world, axis=0))
    
                # Orientation from human arm
                if 'upperarm' in order_key:
                    arm_orient = self.bc.getLinkState(
                        self.humanoid._humanoid,
                        self.right_shoulder,
                        computeForwardKinematics=True,
                        physicsClientId=self.bc._client
                    )[5]
                else:
                    arm_orient = self.bc.getLinkState(
                        self.humanoid._humanoid,
                        self.right_elbow,
                        computeForwardKinematics=True,
                        physicsClientId=self.bc._client
                    )[5]
    
                self.world_to_target_point = [mean_target, arm_orient]
    
                # ---------- IK #1 ----------
                world_to_eef = self.bc.multiplyTransforms(
                    self.world_to_target_point[0],
                    self.world_to_target_point[1],
                    self.target_to_eef[0],
                    self.target_to_eef[1],
                    physicsClientId=self.bc._client
                )
    
                q_robot = self.bc.calculateInverseKinematics(
                    self.robot.id,
                    self.robot.eef_id,
                    world_to_eef[0],
                    world_to_eef[1],
                    lowerLimits=self.robot.arm_lower_limits,
                    upperLimits=self.robot.arm_upper_limits,
                    jointRanges=self.robot.arm_joint_ranges,
                    restPoses=self.robot.arm_rest_poses,
                    maxNumIterations=40,
                    physicsClientId=self.bc._client
                )
                q_robot = q_robot[:len(self.robot.arm_controllable_joints)]
    
                if self.robot_in_collision(q_robot):
                    continue
    
                # NEW: reject if IK doesn't actually reach the pose
                ok, err = ik_reaches_pose(q_robot, world_to_eef[0], max_err=0.03)
                if not ok:
                    continue
    
                # ---------- IK #2 (closer) ----------
                world_to_eef_closer = self.bc.multiplyTransforms(
                    self.world_to_target_point[0],
                    self.world_to_target_point[1],
                    self.target_closer_to_eef[0],
                    self.target_closer_to_eef[1],
                    physicsClientId=self.bc._client
                )
    
                q_robot_closer = self.bc.calculateInverseKinematics(
                    self.robot.id,
                    self.robot.eef_id,
                    world_to_eef_closer[0],
                    world_to_eef_closer[1],
                    lowerLimits=self.robot.arm_lower_limits,
                    upperLimits=self.robot.arm_upper_limits,
                    jointRanges=self.robot.arm_joint_ranges,
                    restPoses=self.robot.arm_rest_poses,
                    maxNumIterations=40,
                    physicsClientId=self.bc._client
                )
                q_robot_closer = q_robot_closer[:len(self.robot.arm_controllable_joints)]
    
                if self.robot_in_collision(q_robot_closer):
                    continue
    
                # NEW: reject if IK doesn't actually reach the closer pose
                ok2, err2 = ik_reaches_pose(q_robot_closer, world_to_eef_closer[0], max_err=0.03)
                if not ok2:
                    continue
    
                # ---------- SUCCESS ----------
                self.feasible_targets_pos_world = targets_pos_world
                self.feasible_targets = targets
                self.feasible_targets_count = len(targets)
    
                # Use closer pose for reset
                self.init_q_R = q_robot_closer
    
                self.arm_side = order_key
                self.target_order_flags[order_key] = True
                feasible_targets_found = True
    
                print(f'[RESET CLOSE] arm_side={self.arm_side}, targets={len(targets)}')
                break
    
            if feasible_targets_found:
                break
    
        return feasible_targets_found
    def get_feasible_targets_posx(self):
        """
        TOOL-aware feasibility:
          - Choose a target point on arm in world.
          - Define desired TOOL pose at that point (world frame).
          - Convert to desired EEF pose using inv(eef_to_tool).
          - Run IK, check collision.
          - Create a "press-in" pose by pushing tool along local -Z (in TOOL frame), run IK again.
          - Use the press pose as init_q_R.
        """
    
        if not hasattr(self, "eef_to_tool") or self.eef_to_tool is None:
            raise RuntimeError("eef_to_tool not initialized. Call init_tool() before generate_targets().")
    
        inv_eef_to_tool = self.bc.invertTransform(
            self.eef_to_tool[0], self.eef_to_tool[1], physicsClientId=self.bc._client
        )
    
        self.target_order_flags = {
            'upperarm_front': False,
            'upperarm_back': False,
            'forearm_front': False,
            'forearm_back': False
        }
    
        self.target_trial_order = ['upperarm_front']
        self.target_axis_trial_order = [0]
    
        feasible_targets_found = False
    
        def split_targets(targets_pos, axis):
            coords = np.array([pos[axis] for pos in targets_pos])
            mid = np.median(coords)
            front_idx = [i for i, pos in enumerate(targets_pos) if pos[axis] > mid]
            back_idx  = [i for i, pos in enumerate(targets_pos) if pos[axis] <= mid]
            return front_idx, back_idx
    
        for axis in self.target_axis_trial_order:
    
            front_u, back_u = split_targets(self.targets_pos_on_upperarm, axis)
            front_f, back_f = split_targets(self.targets_pos_on_forearm, axis)
    
            self.target_pos_world_dict = {
                'upperarm_front': np.array(self.targets_pos_upperarm_world)[front_u],
                'upperarm_back':  np.array(self.targets_pos_upperarm_world)[back_u],
                'forearm_front':  np.array(self.targets_pos_forearm_world)[front_f],
                'forearm_back':   np.array(self.targets_pos_forearm_world)[back_f]
            }
    
            self.target_dict = {
                'upperarm_front': np.array(self.targets_upperarm)[front_u],
                'upperarm_back':  np.array(self.targets_upperarm)[back_u],
                'forearm_front':  np.array(self.targets_forearm)[front_f],
                'forearm_back':   np.array(self.targets_forearm)[back_f]
            }
    
            for order_key in self.target_trial_order:
    
                self.robot.reset()
    
                targets_pos_world = self.target_pos_world_dict[order_key]
                targets = self.target_dict[order_key]
                if len(targets_pos_world) == 0:
                    continue
    
                # pick a real point (not mean)
                target_point_world = tuple(targets_pos_world[0])
    
                # arm orientation at that segment
                if 'upperarm' in order_key:
                    arm_orient = self.bc.getLinkState(
                        self.humanoid._humanoid, self.right_shoulder,
                        computeForwardKinematics=True, physicsClientId=self.bc._client
                    )[5]
                else:
                    arm_orient = self.bc.getLinkState(
                        self.humanoid._humanoid, self.right_elbow,
                        computeForwardKinematics=True, physicsClientId=self.bc._client
                    )[5]
    
                # Desired TOOL pose: at the target point, aligned with the arm
                world_to_tool_des = (target_point_world, arm_orient)
    
                # Convert desired TOOL pose -> desired EEF pose
                world_to_eef = self.bc.multiplyTransforms(
                    world_to_tool_des[0], world_to_tool_des[1],
                    inv_eef_to_tool[0], inv_eef_to_tool[1],
                    physicsClientId=self.bc._client
                )
    
                # IK #1
                q_robot = self.bc.calculateInverseKinematics(
                    self.robot.id, self.robot.eef_id,
                    world_to_eef[0], world_to_eef[1],
                    lowerLimits=self.robot.arm_lower_limits,
                    upperLimits=self.robot.arm_upper_limits,
                    jointRanges=self.robot.arm_joint_ranges,
                    restPoses=self.robot.arm_rest_poses,
                    maxNumIterations=80,
                    physicsClientId=self.bc._client
                )
                q_robot = q_robot[:len(self.robot.arm_controllable_joints)]
                if self.robot_in_collision(q_robot):
                    continue
    
                # "Press in" along TOOL local -Z by 2 cm (tune 0.01–0.03)
                press_in_tool = ([0.0, 0.0, -0.02], [0, 0, 0, 1])
    
                world_to_tool_press = self.bc.multiplyTransforms(
                    world_to_tool_des[0], world_to_tool_des[1],
                    press_in_tool[0], press_in_tool[1],
                    physicsClientId=self.bc._client
                )
    
                world_to_eef_press = self.bc.multiplyTransforms(
                    world_to_tool_press[0], world_to_tool_press[1],
                    inv_eef_to_tool[0], inv_eef_to_tool[1],
                    physicsClientId=self.bc._client
                )
    
                # IK #2 (press)
                q_robot_press = self.bc.calculateInverseKinematics(
                    self.robot.id, self.robot.eef_id,
                    world_to_eef_press[0], world_to_eef_press[1],
                    lowerLimits=self.robot.arm_lower_limits,
                    upperLimits=self.robot.arm_upper_limits,
                    jointRanges=self.robot.arm_joint_ranges,
                    restPoses=self.robot.arm_rest_poses,
                    maxNumIterations=80,
                    physicsClientId=self.bc._client
                )
                q_robot_press = q_robot_press[:len(self.robot.arm_controllable_joints)]
                if self.robot_in_collision(q_robot_press):
                    continue
    
                # success
                self.feasible_targets_pos_world = targets_pos_world
                self.feasible_targets = targets
                self.feasible_targets_count = len(targets)
    
                self.init_q_R = q_robot_press
                self.arm_side = order_key
                self.target_order_flags[order_key] = True
                feasible_targets_found = True
    
                print(f"[RESET CLOSE TOOL-CORRECT] arm_side={self.arm_side}, targets={len(targets)}")
                break
    
            if feasible_targets_found:
                break
    
        return feasible_targets_found