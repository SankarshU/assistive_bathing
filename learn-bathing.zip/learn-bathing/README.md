```bash
conda env create -f environment.yml
conda activate learnbath
```

```bash
# to visualize environment
python env_viewer.py

# to train
python learn.py --train

# to render a trained policy
python learn.py --render

# to evaluate a trained policy
python learn.py --evaluate
```